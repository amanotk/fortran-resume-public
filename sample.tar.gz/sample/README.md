# Fortran演習サンプルコード

東京大学理学部地球惑星物理学科3年生向けの演習科目「地球惑星物理学演習」のFortranサンプルコードです．  
詳細は[Fortran演習](https://amanotk.github.io/fortran-resume-public/)のページを参照してください．

