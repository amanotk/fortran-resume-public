#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" sample code in python
"""

print('Hello, world !')
